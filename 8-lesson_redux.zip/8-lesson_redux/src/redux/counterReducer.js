const initialState = {
    num: isNaN(Number(localStorage.getItem("num"))) ? 0 : Number(localStorage.getItem("num"))
}

const counterReducer = (state = initialState, action) => {
   switch(action.type){
    case "INCREASE_COUNTER":
        localStorage.setItem("num", state.num + action.number)
        return {
            num: state.num + action.number
        }
    case "DECREASE_COUNTER":  
        localStorage.setItem("num", state.num - action.number)
        return {
            num: state.num - action.number
        } 
    case "RESET_COUNTER":  
        localStorage.setItem("num", state.num = 0)
        return {
            num: state.num = 0
        } 
    default:
        return state
    }
}

export { counterReducer }