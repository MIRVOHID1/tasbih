import React from 'react'
import { useDispatch } from "react-redux"
import { useSelector } from 'react-redux';
import "./component.css"

const Main = () => {
    const dispatch = useDispatch();
    const count = useSelector((state) => state.num);

    const handleIncreaseCounter = () => {
      if (count < 99) {
           dispatch({type: "INCREASE_COUNTER", number: 1});
      }
    }
    const handleDecreaseCounter = () => {
      if (count > 0) {
        dispatch({type: "DECREASE_COUNTER", number: 1});
      }
    }
    const handleResetCounter = () => {
      dispatch({ type: "RESET_COUNTER" });
    };

  return (
    <div className='card1'>
        {/* <button className='buttonRole' onClick={handleIncreaseCounter} disabled={count === 99}>Click +</button>
        <button onClick={handleResetCounter} disabled={count === 0}>Reset</button>
        <button className='buttonRole' onClick={handleDecreaseCounter} disabled={count === 0}>Click -</button> */}
      <div className='card2'>
        <button className='buttonRole' onClick={handleDecreaseCounter} disabled={count === 0}><h3>-</h3></button>
        <button className='buttonRole' onClick={handleResetCounter} disabled={count === 0}>Reset</button>
      </div>
      <div>
        <button className='buttonReset' onClick={handleIncreaseCounter} disabled={count === 99}><h2>+</h2></button>
      </div>
    </div>
  )
}

export default Main