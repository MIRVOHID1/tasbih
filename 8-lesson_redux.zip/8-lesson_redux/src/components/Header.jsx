import React, { useEffect, useRef } from "react";
import { useSelector } from "react-redux";
import audio from "../music/ding.mp3"

const Header = () => {
  const count = useSelector((state) => state.num);
  const audioRef = useRef(null);
  // console.log(count);

  useEffect(() => {
    if (count === 33) {
        audioRef.current.play();
    }else if(count === 66){
        audioRef.current.play();
    }else if(count === 99){
      audioRef.current.play();
    }
  }, [count]);

  return (
  <div className='cardNumber'>
    <h1>
    {count}
    </h1>
    <audio ref={audioRef} src={audio} />
  </div>
  )
};

export default Header;
